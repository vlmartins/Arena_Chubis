atk = "4"
hp = "10"

calculo = 324

print(calculo == 5)

print(calculo)
print(type(calculo))